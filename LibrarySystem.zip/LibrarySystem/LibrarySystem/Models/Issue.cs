﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibrarySystem.Models
{
    /// <summary>
    /// Модель для таблицы Issues
    /// </summary>
    [Table("issues")]
    public partial class Issue
    {
        [Key]
        [Column("issue_id")]
        public int IssueId { get; set; }

        [Column("book_id")]
        [Display(Name = "Книга")]
        public int BookId { get; set; }

        [Column("reader_id")]
        [Display(Name = "Читатель")]
        public int ReaderId { get; set; }

        [Column("issue_date", TypeName = "date")]
        [DataType(DataType.Date)]
        [Display(Name = "Дата выдачи")]
        public DateTime IssueDate { get; set; }

        [Column("return_date", TypeName = "date")]
        [DataType(DataType.Date)]
        [Display(Name = "Срок возврата")]
        public DateTime ReturnDate { get; set; }

        [Column("actual_return_date", TypeName = "date")]
        [DataType(DataType.Date)]
        [Display(Name = "Фактическая дата возврата")]
        public DateTime? ActualReturnDate { get; set; }

        [ForeignKey("BookId")]
        [InverseProperty("Issues")]
        [Display(Name = "Книга")]
        public virtual Book? Book { get; set; }

        [ForeignKey("ReaderId")]
        [InverseProperty("Issues")]
        [Display(Name = "Читатель")]
        public virtual Reader? Reader { get; set; }

        [NotMapped]
        [Display(Name = "Дней просрочки")]
        public int DaysOverdue
        {
            get
            {
                if (ActualReturnDate.HasValue)
                    return Math.Max(0, (ActualReturnDate.Value - ReturnDate).Days);
                else
                    return Math.Max(0, (DateTime.Today - ReturnDate).Days);
            }
        }

        [NotMapped]
        [Display(Name = "Статус")]
        public bool IsActive => !ActualReturnDate.HasValue;
    }
}