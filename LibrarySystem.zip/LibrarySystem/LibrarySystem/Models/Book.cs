﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibrarySystem.Models
{
    /// <summary>
    /// Модель для представления книги в библиотечном фонде
    /// </summary>
    /// <remarks>
    /// Содержит информацию о книге:
    /// - Основные данные (название, автор, год издания)
    /// - Идентификационные номера (инвентарный, ISBN)
    /// - Ссылку на отдел библиотеки
    /// - Список выдач этой книги
    /// </remarks>
    [Table("books")]
    public partial class Book
    {
        /// <summary>
        /// Инициализирует новый экземпляр класса Book
        /// </summary>
        public Book()
        {
            Issues = new HashSet<Issue>();
        }

        /// <summary>
        /// Уникальный идентификатор книги (первичный ключ)
        /// </summary>
        [Key]
        [Column("book_id")]
        public int BookId { get; set; }

        /// <summary>
        /// Инвентарный номер книги
        /// </summary>
        /// <value>Уникальный номер для учета экземпляра книги</value>
        [Column("inventory_number")]
        [Display(Name = "Инвентарный номер")]
        public int InventoryNumber { get; set; }

        /// <summary>
        /// Название книги
        /// </summary>
        /// <value>Полное название литературного произведения</value>
        [Required(ErrorMessage = "Название книги обязательно")]
        [Column("title")]
        [StringLength(255, ErrorMessage = "Название не может превышать 255 символов")]
        [Display(Name = "Название")]
        public string Title { get; set; } = null!;

        /// <summary>
        /// Автор книги
        /// </summary>
        /// <value>Фамилия и имя автора (авторов)</value>
        [Required(ErrorMessage = "Автор обязателен")]
        [Column("author")]
        [StringLength(255, ErrorMessage = "Имя автора не может превышать 255 символов")]
        [Display(Name = "Автор")]
        public string Author { get; set; } = null!;

        /// <summary>
        /// Год издания книги
        /// </summary>
        /// <value>Четырехзначный год публикации</value>
        [Column("year")]
        [Range(1000, 2025, ErrorMessage = "Год должен быть между 1000 и 2025")]
        [Display(Name = "Год издания")]
        public int? Year { get; set; }

        /// <summary>
        /// Международный стандартный книжный номер (ISBN)
        /// </summary>
        /// <value>Уникальный номер издания в формате ISBN-10 или ISBN-13</value>
        [Column("isbn")]
        [StringLength(20, ErrorMessage = "ISBN не может превышать 20 символов")]
        [RegularExpression(@"^(?:\d{9}[\dXx]|\d{13})$", ErrorMessage = "Неверный формат ISBN")]
        [Display(Name = "ISBN")]
        public string? Isbn { get; set; }

        /// <summary>
        /// Идентификатор отдела библиотеки (внешний ключ)
        /// </summary>
        /// <value>Ссылка на отдел, где хранится книга</value>
        [Column("department_id")]
        [Display(Name = "Отдел")]
        public int DepartmentId { get; set; }

        /// <summary>
        /// Навигационное свойство к отделу библиотеки
        /// </summary>
        [ForeignKey("DepartmentId")]
        [InverseProperty("Books")]
        [Display(Name = "Отдел")]
        public virtual Department? Department { get; set; }
         
        /// <summary>
        /// Коллекция выдач этой книги
        /// </summary>
        [InverseProperty("Book")]
        public virtual ICollection<Issue> Issues { get; set; }

        /// <summary>
        /// Проверяет, доступна ли книга для выдачи
        /// </summary>
        /// <returns>
        /// true - если книга свободна (все выдачи возвращены)
        /// false - если книга выдана читателю
        /// </returns>
        [NotMapped]
        [Display(Name = "Статус")]
        public bool IsAvailable => Issues.All(i => i.ActualReturnDate != null);

        /// <summary>
        /// Возвращает строковое представление книги
        /// </summary>
        /// <returns>Строка в формате "Название - Автор (Год)"</returns>
        public override string ToString()
        {
            return $"{Title} - {Author} ({Year})";
        }
    }
}