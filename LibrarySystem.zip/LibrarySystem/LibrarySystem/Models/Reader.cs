﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibrarySystem.Models
{
    /// <summary>
    /// Модель для таблицы Readers
    /// </summary>
    [Table("readers")]
    public partial class Reader
    {
        public Reader()
        {
            Issues = new HashSet<Issue>();
        }

        [Key]
        [Column("reader_id")]
        public int ReaderId { get; set; }

        [Required]
        [Column("last_name")]
        [StringLength(100)]
        [Display(Name = "Фамилия")]
        public string LastName { get; set; } = null!;

        [Required]
        [Column("first_name")]
        [StringLength(100)]
        [Display(Name = "Имя")]
        public string FirstName { get; set; } = null!;

        [Column("patronymic")]
        [StringLength(100)]
        [Display(Name = "Отчество")]
        public string? Patronymic { get; set; }

        [Column("card_number")]
        [Display(Name = "Номер билета")]
        public int CardNumber { get; set; }

        [Column("phone")]
        [StringLength(20)]
        [Display(Name = "Телефон")]
        public string? Phone { get; set; }

        [Column("email")]
        [StringLength(100)]
        [Display(Name = "Email")]
        public string? Email { get; set; }

        [InverseProperty("Reader")]
        public virtual ICollection<Issue> Issues { get; set; }

        [NotMapped]
        [Display(Name = "ФИО")]
        public string FullName => $"{LastName} {FirstName} {Patronymic}".Trim();
    }
}