﻿using System;
using System.Collections.Generic;

namespace LibrarySystem.Models;

public partial class Readerstatistic
{
    public int? ReaderId { get; set; }

    public string? Читатель { get; set; }

    public int? НомерБилета { get; set; }

    public long? ВсегоВыдач { get; set; }

    public long? КнигНаРуках { get; set; }

    public DateOnly? ПерваяВыдача { get; set; }

    public DateOnly? ПоследняяВыдача { get; set; }
}
