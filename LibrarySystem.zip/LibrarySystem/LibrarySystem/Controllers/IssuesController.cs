﻿using LibrarySystem.Data;
using LibrarySystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace LibrarySystem.Controllers
{
    /// <summary>
    /// Контроллер для управления выдачами книг
    /// </summary>
    public class IssuesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<IssuesController> _logger;

        /// <summary>
        /// Инициализирует новый экземпляр контроллера IssuesController
        /// </summary>
        /// <param name="context">Контекст базы данных</param>
        /// <param name="logger">Логгер</param>
        public IssuesController(ApplicationDbContext context, ILogger<IssuesController> logger)
        {
            _context = context;
            _logger = logger;
        }

        /// <summary>
        /// Отображает список всех активных выдач (книги на руках)
        /// </summary>
        /// <param name="readerId">ID читателя для фильтрации (опционально)</param>
        /// <param name="bookId">ID книги для фильтрации (опционально)</param>
        /// <returns>Представление со списком активных выдач</returns>
        public async Task<IActionResult> Index(int? readerId = null, int? bookId = null)
        {
            try
            {
                // Базовый запрос: все активные выдачи (книги на руках)
                IQueryable<Issue> query = _context.Issues
                    .Include(i => i.Book!)
                    .ThenInclude(b => b!.Department)
                    .Include(i => i.Reader!)
                    .Where(i => i.ActualReturnDate == null); // Только не возвращенные книги

                // Применяем фильтры
                if (readerId.HasValue)
                {
                    query = query.Where(i => i.ReaderId == readerId.Value);
                }

                if (bookId.HasValue)
                {
                    query = query.Where(i => i.BookId == bookId.Value);
                }

                // Сохраняем параметры фильтров для представления
                ViewBag.ReaderId = readerId;
                ViewBag.BookId = bookId;

                // Получаем данные для выпадающих списков фильтров
                ViewBag.Readers = await GetReadersSelectList();
                ViewBag.Books = await GetBooksSelectList();

                // Выполняем запрос: сначала просроченные, потом остальные
                var issues = await query
                    .OrderByDescending(i => i.ReturnDate < DateTime.Today) // Сначала просроченные
                    .ThenByDescending(i => (DateTime.Today - i.ReturnDate).Days) // По дням просрочки
                    .ThenByDescending(i => i.IssueDate) // По дате выдачи
                    .ToListAsync();

                return View(issues);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при получении списка активных выдач");
                TempData["ErrorMessage"] = "Произошла ошибка при загрузке данных";
                return View(new List<Issue>());
            }
        }

        /// <summary>
        /// Отображает детальную информацию о конкретной выдаче
        /// </summary>
        /// <param name="id">ID выдачи для просмотра</param>
        /// <returns>Представление с детальной информацией о выдаче</returns>
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                _logger.LogWarning("Попытка доступа к деталям выдачи без указания ID");
                return NotFound();
            }

            try
            {
                var issue = await _context.Issues
                    .Include(i => i.Book)
                    .ThenInclude(b => b.Department)
                    .Include(i => i.Reader)
                    .FirstOrDefaultAsync(m => m.IssueId == id);

                if (issue == null)
                {
                    _logger.LogWarning("Выдача с ID {IssueId} не найдена", id);
                    return NotFound();
                }

                return View(issue);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при получении деталей выдачи ID {IssueId}", id);
                TempData["ErrorMessage"] = "Произошла ошибка при загрузке данных";
                return RedirectToAction(nameof(Index));
            }
        }

        /// <summary>
        /// Отображает форму для создания новой выдачи книги
        /// </summary>
        /// <returns>Представление формы создания выдачи</returns>
        public async Task<IActionResult> Create()
        {
            try
            {
                await PrepareCreateViewData();
                return View();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при подготовке данных для создания выдачи");
                TempData["ErrorMessage"] = "Произошла ошибка при загрузке данных";
                return RedirectToAction(nameof(Index));
            }
        }

        /// <summary>
        /// Обрабатывает данные формы для создания новой выдачи
        /// </summary>
        /// <param name="issue">Данные новой выдачи из формы</param>
        /// <returns>Результат обработки: редирект при успехе или форма с ошибками</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IssueId,BookId,ReaderId,IssueDate,ReturnDate")] Issue issue)
        {
            // Устанавливаем даты по умолчанию, если они не указаны
            if (issue.IssueDate == default)
            {
                issue.IssueDate = DateTime.Today;
            }

            if (issue.ReturnDate == default)
            {
                issue.ReturnDate = issue.IssueDate.AddDays(30);
            }

            // Проверяем валидность модели
            if (ModelState.IsValid)
            {
                try
                {
                    // Проверяем, что книга доступна (не выдана другому читателю)
                    var isBookAvailable = !await _context.Issues
                        .AnyAsync(i => i.BookId == issue.BookId && i.ActualReturnDate == null);

                    if (!isBookAvailable)
                    {
                        ModelState.AddModelError("BookId", "Эта книга уже выдана другому читателю");
                        await PrepareCreateViewData();
                        return View(issue);
                    }

                    // Проверяем корректность дат
                    if (issue.ReturnDate <= issue.IssueDate)
                    {
                        ModelState.AddModelError("ReturnDate", "Дата возврата должна быть позже даты выдачи");
                        await PrepareCreateViewData();
                        return View(issue);
                    }

                    // Сохраняем новую выдачу в базе данных
                    _context.Add(issue);
                    await _context.SaveChangesAsync();

                    _logger.LogInformation(
                        "Создана новая выдача ID {IssueId} для книги ID {BookId} и читателя ID {ReaderId}",
                        issue.IssueId, issue.BookId, issue.ReaderId
                    );

                    TempData["SuccessMessage"] = "Книга успешно выдана";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateException ex)
                {
                    _logger.LogError(ex, "Ошибка при создании выдачи");
                    ModelState.AddModelError("", $"Не удалось сохранить выдачу: {ex.Message}");
                    await PrepareCreateViewData();
                    return View(issue);
                }
            }

            // Если модель невалидна, повторно подготавливаем данные для формы
            try
            {
                await PrepareCreateViewData();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при подготовке данных для формы создания");
            }

            return View(issue);
        }

        /// <summary>
        /// Отображает форму подтверждения удаления выдачи
        /// </summary>
        /// <param name="id">ID выдачи для удаления</param>
        /// <returns>Представление подтверждения удаления</returns>
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                _logger.LogWarning("Попытка удаления выдачи без указания ID");
                return NotFound();
            }

            try
            {
                var issue = await _context.Issues
                    .Include(i => i.Book)
                    .Include(i => i.Reader)
                    .FirstOrDefaultAsync(m => m.IssueId == id);

                if (issue == null)
                {
                    _logger.LogWarning("Выдача с ID {IssueId} не найдена для удаления", id);
                    return NotFound();
                }

                return View(issue);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при получении данных для удаления выдачи ID {IssueId}", id);
                TempData["ErrorMessage"] = "Произошла ошибка при загрузке данных";
                return RedirectToAction(nameof(Index));
            }
        }

        /// <summary>
        /// Выполняет удаление выдачи после подтверждения
        /// </summary>
        /// <param name="id">ID выдачи для удаления</param>
        /// <returns>Результат удаления: редирект на список выдач</returns>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var issue = await _context.Issues.FindAsync(id);

                if (issue != null)
                {
                    _context.Issues.Remove(issue);
                    await _context.SaveChangesAsync();

                    _logger.LogInformation("Выдача ID {IssueId} успешно удалена", id);
                    TempData["SuccessMessage"] = "Запись о выдаче успешно удалена";
                }
                else
                {
                    _logger.LogWarning("Попытка удаления несуществующей выдачи ID {IssueId}", id);
                    TempData["ErrorMessage"] = "Запись о выдаче не найдена";
                }
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Ошибка при удалении выдачи ID {IssueId}", id);
                TempData["ErrorMessage"] = $"Не удалось удалить запись: {ex.InnerException?.Message ?? ex.Message}";
                return RedirectToAction(nameof(Delete), new { id });
            }

            return RedirectToAction(nameof(Index));
        }

        #region Вспомогательные методы

        /// <summary>
        /// Подготавливает данные для представления создания выдачи
        /// </summary>
        /// <remarks>
        /// Загружает списки доступных книг и читателей для выпадающих списков
        /// </remarks>
        private async Task PrepareCreateViewData()
        {
            // ВАЖНО: Для создания выдачи показываем только доступные книги
            var availableBooks = await _context.Books
                .Where(b => !b.Issues.Any(i => i.ActualReturnDate == null)) // Только не выданные
                .OrderBy(b => b.Title)
                .ToListAsync();

            // Получаем всех читателей
            var readers = await _context.Readers
                .OrderBy(r => r.LastName)
                .ThenBy(r => r.FirstName)
                .ToListAsync();

            // Подготавливаем данные для выпадающих списков
            ViewData["BookId"] = new SelectList(availableBooks, "BookId", "Title");
            ViewData["ReaderId"] = new SelectList(readers, "ReaderId", "FullName");

            // Устанавливаем значения по умолчанию для дат
            ViewBag.DefaultIssueDate = DateTime.Today;
            ViewBag.DefaultReturnDate = DateTime.Today.AddDays(30);
        }

        /// <summary>
        /// Получает список читателей для выпадающего списка фильтра
        /// </summary>
        /// <returns>Список элементов SelectListItem с данными читателей</returns>
        private async Task<List<SelectListItem>> GetReadersSelectList()
        {
            return await _context.Readers
                .OrderBy(r => r.LastName)
                .Select(r => new SelectListItem
                {
                    Value = r.ReaderId.ToString(),
                    Text = $"{r.LastName} {r.FirstName} {r.Patronymic}".Trim()
                })
                .ToListAsync();
        }

        /// <summary>
        /// Получает список книг для выпадающего списка фильтра
        /// </summary>
        /// <returns>Список элементов SelectListItem с данными книг</returns>
        private async Task<List<SelectListItem>> GetBooksSelectList()
        {
            return await _context.Books
                .OrderBy(b => b.Title)
                .Select(b => new SelectListItem
                {
                    Value = b.BookId.ToString(),
                    Text = $"{b.Title} ({b.Author})"
                })
                .ToListAsync();
        }

        #endregion
    }
}