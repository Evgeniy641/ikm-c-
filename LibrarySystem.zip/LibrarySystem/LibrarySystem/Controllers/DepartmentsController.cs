﻿using LibrarySystem.Data;
using LibrarySystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace LibrarySystem.Controllers
{
    public class DepartmentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DepartmentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Departments
        public async Task<IActionResult> Index(string searchString)
        {
            var query = _context.Departments.AsQueryable();

            if (!string.IsNullOrEmpty(searchString))
            {
                query = query.Where(d =>
                    d.DepartmentName.Contains(searchString) ||
                    (d.Location != null && d.Location.Contains(searchString)));
            }

            ViewData["CurrentFilter"] = searchString;
            var departments = await query.OrderBy(d => d.DepartmentName).ToListAsync();
            return View(departments);
        }

        // GET: Departments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var department = await _context.Departments
                .Include(d => d.Books)
                .FirstOrDefaultAsync(m => m.DepartmentId == id);

            if (department == null)
            {
                return NotFound();
            }

            // Статистика
            var books = department.Books.ToList();
            ViewBag.BooksCount = books.Count;
            ViewBag.AvailableBooksCount = books.Count(b =>
                b.Issues == null || !b.Issues.Any() || b.Issues.All(i => i.ActualReturnDate != null));

            return View(department);
        }

        // GET: Departments/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Departments/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DepartmentId,DepartmentName,Location")] Department department)
        {
            if (ModelState.IsValid)
            {
                // Проверка уникальности названия
                if (_context.Departments.Any(d => d.DepartmentName == department.DepartmentName))
                {
                    ModelState.AddModelError("DepartmentName", "Отдел с таким названием уже существует");
                    return View(department);
                }

                _context.Add(department);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Отдел успешно создан";
                return RedirectToAction(nameof(Index));
            }

            return View(department);
        }

        // GET: Departments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var department = await _context.Departments.FindAsync(id);
            if (department == null)
            {
                return NotFound();
            }

            return View(department);
        }

        // POST: Departments/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DepartmentId,DepartmentName,Location")] Department department)
        {
            if (id != department.DepartmentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                // Проверка уникальности названия
                if (_context.Departments.Any(d =>
                    d.DepartmentName == department.DepartmentName &&
                    d.DepartmentId != department.DepartmentId))
                {
                    ModelState.AddModelError("DepartmentName", "Отдел с таким названием уже существует");
                    return View(department);
                }

                try
                {
                    _context.Update(department);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Данные отдела успешно обновлены";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DepartmentExists(department.DepartmentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(department);
        }

        // GET: Departments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var department = await _context.Departments
                .Include(d => d.Books)
                .FirstOrDefaultAsync(m => m.DepartmentId == id);

            if (department == null)
            {
                return NotFound();
            }

            // Проверяем книги в отделе
            ViewBag.HasBooks = department.Books.Any();
            ViewBag.BooksCount = department.Books.Count;

            return View(department);
        }

        // POST: Departments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var department = await _context.Departments
                .Include(d => d.Books)
                .FirstOrDefaultAsync(d => d.DepartmentId == id);

            if (department != null)
            {
                // Проверяем книги в отделе
                if (department.Books.Any())
                {
                    TempData["ErrorMessage"] = $"Невозможно удалить отдел: в нем есть книги ({department.Books.Count} шт.). " +
                        "Сначала переместите или удалите все книги из этого отдела.";
                    return RedirectToAction(nameof(Delete), new { id });
                }

                _context.Departments.Remove(department);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Отдел успешно удален";
            }

            return RedirectToAction(nameof(Index));
        }

        private bool DepartmentExists(int id)
        {
            return _context.Departments.Any(e => e.DepartmentId == id);
        }
    }
}