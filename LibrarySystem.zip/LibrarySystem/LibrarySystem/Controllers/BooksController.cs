﻿using LibrarySystem.Data;
using LibrarySystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace LibrarySystem.Controllers
{
    public class BooksController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BooksController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Books
        public async Task<IActionResult> Index(string searchString)
        {
            // Базовый запрос с включением отдела
            IQueryable<Book> query = _context.Books
                .Include(b => b.Department);

            if (!string.IsNullOrEmpty(searchString))
            {
                query = query.Where(s =>
                    s.Title.Contains(searchString) ||
                    s.Author.Contains(searchString) ||
                    (s.Isbn != null && s.Isbn.Contains(searchString)));
            }

            ViewBag.SearchString = searchString;
            var books = await query.ToListAsync();
            return View(books);
        }

        // GET: Books/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .Include(b => b.Department)
                .Include(b => b.Issues)
                .ThenInclude(i => i.Reader)
                .FirstOrDefaultAsync(m => m.BookId == id);

            if (book == null)
            {
                return NotFound();
            }

            // Проверяем доступность книги
            ViewBag.IsAvailable = book.Issues == null || !book.Issues.Any() ||
                                book.Issues.All(i => i.ActualReturnDate != null);

            return View(book);
        }

        // GET: Books/Create
        public async Task<IActionResult> Create()
        {
            await LoadDepartments();
            return View();
        }

        // POST: Books/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BookId,InventoryNumber,Title,Author,Year,Isbn,DepartmentId")] Book book)
        {
            if (ModelState.IsValid)
            {
                // Проверка уникальности инвентарного номера
                if (_context.Books.Any(b => b.InventoryNumber == book.InventoryNumber))
                {
                    ModelState.AddModelError("InventoryNumber", "Инвентарный номер уже существует");
                    await LoadDepartments();
                    return View(book);
                }

                _context.Add(book);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Книга успешно добавлена";
                return RedirectToAction(nameof(Index));
            }

            await LoadDepartments();
            return View(book);
        }

        // GET: Books/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound();
            }

            await LoadDepartments();
            return View(book);
        }

        // POST: Books/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookId,InventoryNumber,Title,Author,Year,Isbn,DepartmentId")] Book book)
        {
            if (id != book.BookId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                // Проверка уникальности инвентарного номера
                if (_context.Books.Any(b => b.InventoryNumber == book.InventoryNumber && b.BookId != book.BookId))
                {
                    ModelState.AddModelError("InventoryNumber", "Инвентарный номер уже существует");
                    await LoadDepartments();
                    return View(book);
                }

                try
                {
                    _context.Update(book);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Книга успешно обновлена";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(book.BookId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            await LoadDepartments();
            return View(book);
        }

        // GET: Books/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .Include(b => b.Department)
                .Include(b => b.Issues)
                .FirstOrDefaultAsync(m => m.BookId == id);

            if (book == null)
            {
                return NotFound();
            }

            // Проверяем активные выдачи
            var hasActiveIssues = book.Issues != null && book.Issues.Any(i => i.ActualReturnDate == null);
            ViewBag.HasActiveIssues = hasActiveIssues;

            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var book = await _context.Books
                .Include(b => b.Issues)
                .FirstOrDefaultAsync(b => b.BookId == id);

            if (book != null)
            {
                // Проверяем активные выдачи
                var hasActiveIssues = book.Issues != null && book.Issues.Any(i => i.ActualReturnDate == null);

                if (hasActiveIssues)
                {
                    TempData["ErrorMessage"] = "Невозможно удалить книгу: есть активные выдачи";
                    return RedirectToAction(nameof(Delete), new { id });
                }

                _context.Books.Remove(book);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Книга успешно удалена";
            }

            return RedirectToAction(nameof(Index));
        }

        private bool BookExists(int id)
        {
            return _context.Books.Any(e => e.BookId == id);
        }

        private async Task LoadDepartments()
        {
            var departments = await _context.Departments.ToListAsync();
            ViewBag.Departments = new SelectList(departments, "DepartmentId", "DepartmentName");
        }
    }
}