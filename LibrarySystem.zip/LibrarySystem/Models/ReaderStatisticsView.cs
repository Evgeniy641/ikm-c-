﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibrarySystem.Models
{
    [Table("ReaderStatistics", Schema = "public")]
    public class ReaderStatisticsView
    {
        [Key]
        [Column("reader_id")]
        public int ReaderId { get; set; }

        [Column("читатель")]
        public string ReaderName { get; set; } = string.Empty;

        [Column("номер_билета")]
        public int CardNumber { get; set; }

        [Column("всего_выдач")]
        public int TotalIssues { get; set; }

        [Column("книг_на_руках")]
        public int BooksOnHand { get; set; }

        [Column("первая_выдача")]
        public DateTime? FirstIssueDate { get; set; }

        [Column("последняя_выдача")]
        public DateTime? LastIssueDate { get; set; }
    }
}