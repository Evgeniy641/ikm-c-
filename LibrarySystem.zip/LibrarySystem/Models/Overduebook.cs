﻿using System;
using System.Collections.Generic;

namespace LibrarySystem.Models;

public partial class Overduebook
{
    public int? IssueId { get; set; }

    public string? Книга { get; set; }

    public string? Автор { get; set; }

    public string? Читатель { get; set; }

    public int? НомерБилета { get; set; }

    public DateOnly? ДатаВыдачи { get; set; }

    public DateOnly? СрокВозврата { get; set; }

    public int? ДнейПросрочки { get; set; }
}
