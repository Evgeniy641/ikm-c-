﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibrarySystem.Models
{
    [Table("OverdueBooks", Schema = "public")] // Указываем имя представления
    public class OverdueBookView
    {
        [Key]
        [Column("issue_id")]
        public int IssueId { get; set; }

        [Column("книга")]
        public string BookTitle { get; set; } = string.Empty;

        [Column("автор")]
        public string BookAuthor { get; set; } = string.Empty;

        [Column("читатель")]
        public string ReaderName { get; set; } = string.Empty;

        [Column("номер_билета")]
        public int CardNumber { get; set; }

        [Column("дата_выдачи")]
        public DateTime IssueDate { get; set; }

        [Column("срок_возврата")]
        public DateTime ReturnDate { get; set; }

        [Column("дней_просрочки")]
        public int DaysOverdue { get; set; }
    }
}