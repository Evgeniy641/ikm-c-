﻿using System;
using System.Collections.Generic;

namespace LibrarySystem.Models;

public partial class Bookpopularity
{
    public int? BookId { get; set; }

    public string? Книга { get; set; }

    public string? Автор { get; set; }

    public int? ГодИздания { get; set; }

    public string? Отдел { get; set; }

    public long? КоличествоВыдач { get; set; }

    public long? УникальныхЧитателей { get; set; }
}
