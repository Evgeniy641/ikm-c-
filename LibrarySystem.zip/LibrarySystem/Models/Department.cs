﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibrarySystem.Models
{
    /// <summary>
    /// Модель для таблицы Departments
    /// </summary>
    [Table("departments")]
    public partial class Department
    {
        public Department()
        {
            Books = new HashSet<Book>();
        }

        [Key]
        [Column("department_id")]
        public int DepartmentId { get; set; }

        [Required]
        [Column("department_name")]
        [StringLength(100)]
        [Display(Name = "Название отдела")]
        public string DepartmentName { get; set; } = null!;

        [Column("location")]
        [StringLength(100)]
        [Display(Name = "Расположение")]
        public string? Location { get; set; }

        [InverseProperty("Department")]
        public virtual ICollection<Book> Books { get; set; }
    }
}