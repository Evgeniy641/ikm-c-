﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibrarySystem.Models
{
    [Table("BookPopularity", Schema = "public")]
    public class BookPopularityView
    {
        [Key]
        [Column("book_id")]
        public int BookId { get; set; }

        [Column("книга")]
        public string BookTitle { get; set; } = string.Empty;

        [Column("автор")]
        public string BookAuthor { get; set; } = string.Empty;

        [Column("год_издания")]
        public int? Year { get; set; }

        [Column("отдел")]
        public string DepartmentName { get; set; } = string.Empty;

        [Column("количество_выдач")]
        public int IssueCount { get; set; }

        [Column("уникальных_читателей")]
        public int UniqueReaders { get; set; }
    }
}