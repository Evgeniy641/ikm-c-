﻿using LibrarySystem.Models;
using Microsoft.EntityFrameworkCore;

namespace LibrarySystem.Data
{
    public partial class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Book> Books { get; set; }
        public virtual DbSet<Department> Departments { get; set; }
        public virtual DbSet<Issue> Issues { get; set; }
        public virtual DbSet<Reader> Readers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=LibraryDB;Username=postgres;Password=ваш_пароль");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Явно указываем имена таблиц в нижнем регистре
            modelBuilder.Entity<Book>().ToTable("books");
            modelBuilder.Entity<Department>().ToTable("departments");
            modelBuilder.Entity<Issue>().ToTable("issues");
            modelBuilder.Entity<Reader>().ToTable("readers");

            // Указываем точные имена столбцов
            modelBuilder.Entity<Book>(entity =>
            {
                entity.HasKey(e => e.BookId).HasName("books_pkey");
                entity.Property(e => e.BookId).HasColumnName("book_id");
                entity.Property(e => e.InventoryNumber).HasColumnName("inventory_number");
                entity.Property(e => e.Title).HasColumnName("title");
                entity.Property(e => e.Author).HasColumnName("author");
                entity.Property(e => e.Year).HasColumnName("year");
                entity.Property(e => e.Isbn).HasColumnName("isbn");
                entity.Property(e => e.DepartmentId).HasColumnName("department_id");

                entity.HasIndex(e => e.InventoryNumber).HasDatabaseName("idx_books_inventory");
                entity.HasIndex(e => e.DepartmentId).HasDatabaseName("idx_books_department");

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.Books)
                    .HasForeignKey(d => d.DepartmentId)
                    .HasConstraintName("fk_department");
            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.HasKey(e => e.DepartmentId).HasName("departments_pkey");
                entity.Property(e => e.DepartmentId).HasColumnName("department_id");
                entity.Property(e => e.DepartmentName).HasColumnName("department_name");
                entity.Property(e => e.Location).HasColumnName("location");
            });

            modelBuilder.Entity<Issue>(entity =>
            {
                entity.HasKey(e => e.IssueId).HasName("issues_pkey");
                entity.Property(e => e.IssueId).HasColumnName("issue_id");
                entity.Property(e => e.BookId).HasColumnName("book_id");
                entity.Property(e => e.ReaderId).HasColumnName("reader_id");
                entity.Property(e => e.IssueDate).HasColumnName("issue_date");
                entity.Property(e => e.ReturnDate).HasColumnName("return_date");
                entity.Property(e => e.ActualReturnDate).HasColumnName("actual_return_date");

                entity.HasIndex(e => e.BookId).HasDatabaseName("idx_issues_book");
                entity.HasIndex(e => e.ReaderId).HasDatabaseName("idx_issues_reader");
                entity.HasIndex(e => new { e.IssueDate, e.ReturnDate }).HasDatabaseName("idx_issues_dates");

                entity.HasOne(d => d.Book)
                    .WithMany(p => p.Issues)
                    .HasForeignKey(d => d.BookId)
                    .HasConstraintName("fk_book");

                entity.HasOne(d => d.Reader)
                    .WithMany(p => p.Issues)
                    .HasForeignKey(d => d.ReaderId)
                    .HasConstraintName("fk_reader");
            });

            modelBuilder.Entity<Reader>(entity =>
            {
                entity.HasKey(e => e.ReaderId).HasName("readers_pkey");
                entity.Property(e => e.ReaderId).HasColumnName("reader_id");
                entity.Property(e => e.LastName).HasColumnName("last_name");
                entity.Property(e => e.FirstName).HasColumnName("first_name");
                entity.Property(e => e.Patronymic).HasColumnName("patronymic");
                entity.Property(e => e.CardNumber).HasColumnName("card_number");
                entity.Property(e => e.Phone).HasColumnName("phone");
                entity.Property(e => e.Email).HasColumnName("email");

                entity.HasIndex(e => e.CardNumber).HasDatabaseName("idx_readers_card").IsUnique();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}