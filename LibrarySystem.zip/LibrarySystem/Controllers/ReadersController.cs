﻿using LibrarySystem.Data;
using LibrarySystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace LibrarySystem.Controllers
{
    public class ReadersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ReadersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Readers
        public async Task<IActionResult> Index(string searchString)
        {
            var query = _context.Readers.AsQueryable();

            if (!string.IsNullOrEmpty(searchString))
            {
                query = query.Where(r =>
                    r.LastName.Contains(searchString) ||
                    r.FirstName.Contains(searchString) ||
                    r.Patronymic.Contains(searchString) ||
                    r.CardNumber.ToString().Contains(searchString));
            }

            ViewData["CurrentFilter"] = searchString;
            var readers = await query.OrderBy(r => r.LastName).ThenBy(r => r.FirstName).ToListAsync();
            return View(readers);
        }

        // GET: Readers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reader = await _context.Readers
                .Include(r => r.Issues)
                .ThenInclude(i => i.Book)
                .FirstOrDefaultAsync(m => m.ReaderId == id);

            if (reader == null)
            {
                return NotFound();
            }

            ViewBag.ActiveIssues = reader.Issues.Count(i => i.ActualReturnDate == null);
            ViewBag.TotalIssues = reader.Issues.Count;

            return View(reader);
        }

        // GET: Readers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Readers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ReaderId,LastName,FirstName,Patronymic,CardNumber,Phone,Email")] Reader reader)
        {
            if (ModelState.IsValid)
            {
                // Проверка уникальности номера билета
                if (_context.Readers.Any(r => r.CardNumber == reader.CardNumber))
                {
                    ModelState.AddModelError("CardNumber", "Читатель с таким номером билета уже существует");
                    return View(reader);
                }

                _context.Add(reader);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Читатель успешно добавлен";
                return RedirectToAction(nameof(Index));
            }

            return View(reader);
        }

        // GET: Readers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reader = await _context.Readers.FindAsync(id);
            if (reader == null)
            {
                return NotFound();
            }

            return View(reader);
        }

        // POST: Readers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ReaderId,LastName,FirstName,Patronymic,CardNumber,Phone,Email")] Reader reader)
        {
            if (id != reader.ReaderId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                // Проверка уникальности номера билета
                if (_context.Readers.Any(r => r.CardNumber == reader.CardNumber && r.ReaderId != reader.ReaderId))
                {
                    ModelState.AddModelError("CardNumber", "Читатель с таким номером билета уже существует");
                    return View(reader);
                }

                try
                {
                    _context.Update(reader);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Данные читателя успешно обновлены";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReaderExists(reader.ReaderId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(reader);
        }

        // GET: Readers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reader = await _context.Readers
                .FirstOrDefaultAsync(m => m.ReaderId == id);

            if (reader == null)
            {
                return NotFound();
            }

            // Проверяем активные выдачи
            var hasActiveIssues = await _context.Issues
                .AnyAsync(i => i.ReaderId == id && i.ActualReturnDate == null);

            ViewBag.HasActiveIssues = hasActiveIssues;

            return View(reader);
        }

        // POST: Readers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reader = await _context.Readers.FindAsync(id);

            if (reader != null)
            {
                // Проверяем активные выдачи
                var hasActiveIssues = await _context.Issues
                    .AnyAsync(i => i.ReaderId == id && i.ActualReturnDate == null);

                if (hasActiveIssues)
                {
                    TempData["ErrorMessage"] = "Невозможно удалить читателя: у него есть не возвращенные книги";
                    return RedirectToAction(nameof(Delete), new { id });
                }

                _context.Readers.Remove(reader);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Читатель успешно удален";
            }

            return RedirectToAction(nameof(Index));
        }

        private bool ReaderExists(int id)
        {
            return _context.Readers.Any(e => e.ReaderId == id);
        }
    }
}