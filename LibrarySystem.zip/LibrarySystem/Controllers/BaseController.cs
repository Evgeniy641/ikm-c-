﻿using Microsoft.AspNetCore.Mvc;

namespace LibrarySystem.Controllers
{
    /// <summary>
    /// Базовый контроллер с общими методами
    /// </summary>
    public class BaseController : Controller
    {
        /// <summary>
        /// Отображает сообщение об ошибке
        /// </summary>
        protected void ShowError(string message)
        {
            TempData["Error"] = message;
        }

        /// <summary>
        /// Отображает сообщение об успехе
        /// </summary>
        protected void ShowSuccess(string message)
        {
            TempData["Success"] = message;
        }
    }
}