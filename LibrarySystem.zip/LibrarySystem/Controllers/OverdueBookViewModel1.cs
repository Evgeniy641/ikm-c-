﻿namespace LibrarySystem.Controllers
{
    internal class OverdueBookViewModel1
    {
        public int IssueId { get; internal set; }
    }
}