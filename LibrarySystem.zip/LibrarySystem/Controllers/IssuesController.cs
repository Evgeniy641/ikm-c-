﻿using LibrarySystem.Data;
using LibrarySystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace LibrarySystem.Controllers
{
    /// <summary>
    /// Контроллер для управления выдачами книг
    /// </summary>
    public class IssuesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public IssuesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Issues
        public async Task<IActionResult> Index(string status = "all", int? readerId = null, int? bookId = null)
        {
            // Базовый запрос с включением связанных данных
            IQueryable<Issue> query = _context.Issues
                .Include(i => i.Book)
                .ThenInclude(b => b.Department)
                .Include(i => i.Reader);

            // Применяем фильтры
            switch (status.ToLower())
            {
                case "active":
                    query = query.Where(i => i.ActualReturnDate == null);
                    break;
                case "returned":
                    query = query.Where(i => i.ActualReturnDate != null);
                    break;
                case "overdue":
                    query = query.Where(i => i.ActualReturnDate == null && i.ReturnDate < DateTime.Today);
                    break;
            }

            if (readerId.HasValue)
            {
                query = query.Where(i => i.ReaderId == readerId.Value);
            }

            if (bookId.HasValue)
            {
                query = query.Where(i => i.BookId == bookId.Value);
            }

            // Сохраняем параметры
            ViewBag.Status = status;
            ViewBag.ReaderId = readerId;
            ViewBag.BookId = bookId;

            // Получаем данные для фильтров
            ViewBag.Readers = await GetReadersSelectList();
            ViewBag.Books = await GetBooksSelectList();

            // Выполняем запрос
            var issues = await query
                .OrderByDescending(i => i.IssueDate)
                .ThenByDescending(i => i.IssueId)
                .ToListAsync();

            return View(issues);
        }

        // GET: Issues/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var issue = await _context.Issues
                .Include(i => i.Book)
                .ThenInclude(b => b.Department)
                .Include(i => i.Reader)
                .FirstOrDefaultAsync(m => m.IssueId == id);

            if (issue == null)
            {
                return NotFound();
            }

            return View(issue);
        }

        // GET: Issues/Create
        public async Task<IActionResult> Create()
        {
            await PrepareCreateViewData();
            return View();
        }

        // POST: Issues/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IssueId,BookId,ReaderId,IssueDate,ReturnDate")] Issue issue)
        {
            // Устанавливаем даты по умолчанию
            if (issue.IssueDate == default)
            {
                issue.IssueDate = DateTime.Today;
            }

            if (issue.ReturnDate == default)
            {
                issue.ReturnDate = issue.IssueDate.AddDays(30);
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Проверка доступности книги
                    var isBookAvailable = !await _context.Issues
                        .AnyAsync(i => i.BookId == issue.BookId && i.ActualReturnDate == null);

                    if (!isBookAvailable)
                    {
                        ModelState.AddModelError("BookId", "Эта книга уже выдана другому читателю");
                        await PrepareCreateViewData();
                        return View(issue);
                    }

                    // Проверка дат
                    if (issue.ReturnDate <= issue.IssueDate)
                    {
                        ModelState.AddModelError("ReturnDate", "Дата возврата должна быть позже даты выдачи");
                        await PrepareCreateViewData();
                        return View(issue);
                    }

                    // Сохраняем выдачу
                    _context.Add(issue);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Книга успешно выдана";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateException ex)
                {
                    ModelState.AddModelError("", $"Не удалось сохранить выдачу: {ex.Message}");
                    await PrepareCreateViewData();
                    return View(issue);
                }
            }

            // Если модель невалидна, заново подготавливаем данные для формы
            await PrepareCreateViewData();
            return View(issue);
        }

        // GET: Issues/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var issue = await _context.Issues.FindAsync(id);
            if (issue == null)
            {
                return NotFound();
            }

            await PrepareEditViewData(issue);
            return View(issue);
        }

        // POST: Issues/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IssueId,BookId,ReaderId,IssueDate,ReturnDate,ActualReturnDate")] Issue issue)
        {
            if (id != issue.IssueId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Если книга уже возвращена, нельзя менять основные данные
                    if (issue.ActualReturnDate.HasValue)
                    {
                        // Проверяем, не пытаются ли изменить основные данные возвращенной книги
                        var originalIssue = await _context.Issues
                            .AsNoTracking()
                            .FirstOrDefaultAsync(i => i.IssueId == id);

                        if (originalIssue != null &&
                            (originalIssue.BookId != issue.BookId ||
                             originalIssue.ReaderId != issue.ReaderId))
                        {
                            ModelState.AddModelError("", "Нельзя изменить книгу или читателя для возвращенной выдачи");
                            await PrepareEditViewData(issue);
                            return View(issue);
                        }
                    }
                    else
                    {
                        // Для активной выдачи проверяем доступность книги (кроме текущей выдачи)
                        var isBookAvailable = !await _context.Issues
                            .AnyAsync(i => i.BookId == issue.BookId &&
                                          i.ActualReturnDate == null &&
                                          i.IssueId != issue.IssueId);

                        if (!isBookAvailable)
                        {
                            ModelState.AddModelError("BookId", "Эта книга уже выдана другому читателю");
                            await PrepareEditViewData(issue);
                            return View(issue);
                        }
                    }

                    _context.Update(issue);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Данные выдачи успешно обновлены";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!IssueExists(issue.IssueId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (DbUpdateException ex)
                {
                    ModelState.AddModelError("", $"Не удалось обновить выдачу: {ex.Message}");
                    await PrepareEditViewData(issue);
                    return View(issue);
                }
            }

            await PrepareEditViewData(issue);
            return View(issue);
        }

        // GET: Issues/Return/5
        public async Task<IActionResult> Return(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var issue = await _context.Issues
                .Include(i => i.Book)
                .Include(i => i.Reader)
                .FirstOrDefaultAsync(m => m.IssueId == id);

            if (issue == null)
            {
                return NotFound();
            }

            if (issue.ActualReturnDate.HasValue)
            {
                TempData["ErrorMessage"] = "Книга уже возвращена";
                return RedirectToAction(nameof(Index));
            }

            return View(issue);
        }

        // POST: Issues/Return/5
        [HttpPost, ActionName("Return")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ReturnConfirmed(int id)
        {
            var issue = await _context.Issues.FindAsync(id);

            if (issue == null)
            {
                return NotFound();
            }

            if (issue.ActualReturnDate.HasValue)
            {
                TempData["ErrorMessage"] = "Книга уже возвращена";
                return RedirectToAction(nameof(Index));
            }

            try
            {
                issue.ActualReturnDate = DateTime.Today;
                _context.Update(issue);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Книга успешно возвращена";
            }
            catch (DbUpdateException ex)
            {
                TempData["ErrorMessage"] = $"Не удалось зарегистрировать возврат: {ex.Message}";
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: Issues/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var issue = await _context.Issues
                .Include(i => i.Book)
                .Include(i => i.Reader)
                .FirstOrDefaultAsync(m => m.IssueId == id);

            if (issue == null)
            {
                return NotFound();
            }

            return View(issue);
        }

        // POST: Issues/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var issue = await _context.Issues.FindAsync(id);

            if (issue != null)
            {
                try
                {
                    _context.Issues.Remove(issue);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Запись о выдаче успешно удалена";
                }
                catch (DbUpdateException ex)
                {
                    TempData["ErrorMessage"] = $"Не удалось удалить запись: {ex.Message}";
                    return RedirectToAction(nameof(Delete), new { id });
                }
            }

            return RedirectToAction(nameof(Index));
        }

        // Вспомогательные методы
        private bool IssueExists(int id)
        {
            return _context.Issues.Any(e => e.IssueId == id);
        }

        private async Task PrepareCreateViewData()
        {
            // Получаем доступные книги (не выданные)
            var availableBooks = await _context.Books
                .Where(b => !b.Issues.Any(i => i.ActualReturnDate == null))
                .OrderBy(b => b.Title)
                .ToListAsync();

            // Получаем всех читателей
            var readers = await _context.Readers
                .OrderBy(r => r.LastName)
                .ThenBy(r => r.FirstName)
                .ToListAsync();

            ViewData["BookId"] = new SelectList(availableBooks, "BookId", "Title");
            ViewData["ReaderId"] = new SelectList(readers, "ReaderId", "FullName");
            ViewBag.DefaultIssueDate = DateTime.Today;
            ViewBag.DefaultReturnDate = DateTime.Today.AddDays(30);
        }

        private async Task PrepareEditViewData(Issue issue)
        {
            // Для редактирования показываем все книги
            var books = await _context.Books
                .OrderBy(b => b.Title)
                .ToListAsync();

            var readers = await _context.Readers
                .OrderBy(r => r.LastName)
                .ThenBy(r => r.FirstName)
                .ToListAsync();

            ViewData["BookId"] = new SelectList(books, "BookId", "Title", issue.BookId);
            ViewData["ReaderId"] = new SelectList(readers, "ReaderId", "FullName", issue.ReaderId);
        }

        private async Task<List<SelectListItem>> GetReadersSelectList()
        {
            return await _context.Readers
                .OrderBy(r => r.LastName)
                .Select(r => new SelectListItem
                {
                    Value = r.ReaderId.ToString(),
                    Text = $"{r.LastName} {r.FirstName} {r.Patronymic}".Trim()
                })
                .ToListAsync();
        }

        private async Task<List<SelectListItem>> GetBooksSelectList()
        {
            return await _context.Books
                .OrderBy(b => b.Title)
                .Select(b => new SelectListItem
                {
                    Value = b.BookId.ToString(),
                    Text = $"{b.Title} ({b.Author})"
                })
                .ToListAsync();
        }

        // Отчет: Просроченные книги
        public async Task<IActionResult> OverdueBooks()
        {
            var overdueIssues = await _context.Issues
                .Include(i => i.Book)
                .Include(i => i.Reader)
                .Where(i => i.ActualReturnDate == null && i.ReturnDate < DateTime.Today)
                .OrderByDescending(i => (DateTime.Today - i.ReturnDate).Days)
                .Select(i => new OverdueBookViewModel
                {
                    IssueId = i.IssueId,
                    BookTitle = i.Book.Title,
                    BookAuthor = i.Book.Author,
                    ReaderName = $"{i.Reader.LastName} {i.Reader.FirstName} {i.Reader.Patronymic}".Trim(),
                    CardNumber = i.Reader.CardNumber,
                    IssueDate = i.IssueDate,
                    ReturnDate = i.ReturnDate,
                    DaysOverdue = (DateTime.Today - i.ReturnDate).Days
                })
                .ToListAsync();

            return View(overdueIssues);
        }
    }

    // ViewModel для отчета по просроченным книгам
    public class OverdueBookViewModel
    {
        public int IssueId { get; set; }
        public string BookTitle { get; set; } = string.Empty;
        public string BookAuthor { get; set; } = string.Empty;
        public string ReaderName { get; set; } = string.Empty;
        public int CardNumber { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public int DaysOverdue { get; set; }
    }
}