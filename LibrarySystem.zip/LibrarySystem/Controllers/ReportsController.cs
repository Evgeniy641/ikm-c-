﻿using LibrarySystem.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibrarySystem.Controllers
{
    public class ReportsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ReportsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Отчет: Просроченные книги
        public async Task<IActionResult> OverdueBooks()
        {
            var overdueBooks = await _context.Database
                .SqlQueryRaw<OverdueBookViewModel>(
                    @"SELECT 
                        issue_id AS IssueId,
                        книга AS BookTitle,
                        автор AS BookAuthor,
                        читатель AS ReaderName,
                        номер_билета AS CardNumber,
                        дата_выдачи AS IssueDate,
                        срок_возврата AS ReturnDate,
                        дней_просрочки AS DaysOverdue
                      FROM OverdueBooks 
                      ORDER BY дней_просрочки DESC")
                .ToListAsync();

            return View(overdueBooks);
        }

        // Отчет: Статистика по читателям
        public async Task<IActionResult> ReaderStatistics()
        {
            var statistics = await _context.Database
                .SqlQueryRaw<ReaderStatisticsViewModel>(
                    @"SELECT 
                        reader_id AS ReaderId,
                        читатель AS ReaderName,
                        номер_билета AS CardNumber,
                        всего_выдач AS TotalIssues,
                        книг_на_руках AS BooksOnHand,
                        первая_выдача AS FirstIssue,
                        последняя_выдача AS LastIssue
                      FROM ReaderStatistics 
                      ORDER BY всего_выдач DESC")
                .ToListAsync();

            return View(statistics);
        }

        // Отчет: Популярность книг
        public async Task<IActionResult> BookPopularity()
        {
            var popularity = await _context.Database
                .SqlQueryRaw<BookPopularityViewModel>(
                    @"SELECT 
                        book_id AS BookId,
                        книга AS BookTitle,
                        автор AS Author,
                        год_издания AS PublicationYear,
                        отдел AS Department,
                        количество_выдач AS IssueCount,
                        уникальных_читателей AS UniqueReaders
                      FROM BookPopularity
                      ORDER BY количество_выдач DESC")
                .ToListAsync();

            return View(popularity);
        }

        // Отчет: Ежемесячная статистика
        public async Task<IActionResult> MonthlyStatistics()
        {
            var monthlyStats = await _context.Database
                .SqlQueryRaw<MonthlyStatisticsViewModel>(
                    @"SELECT 
                        TO_CHAR(issue_date, 'YYYY-MM') AS Month,
                        COUNT(*) AS TotalIssues,
                        COUNT(DISTINCT reader_id) AS UniqueReaders,
                        COUNT(DISTINCT book_id) AS UniqueBooks,
                        ROUND(AVG(EXTRACT(DAY FROM (return_date - issue_date))), 1) AS AverageLoanPeriod
                    FROM issues
                    GROUP BY TO_CHAR(issue_date, 'YYYY-MM')
                    ORDER BY Month DESC")
                .ToListAsync();

            return View(monthlyStats);
        }
    }

    // ViewModels для отчетов
    public class ReaderStatisticsViewModel
    {
        public int ReaderId { get; set; }
        public string ReaderName { get; set; } = string.Empty;
        public int CardNumber { get; set; }
        public int TotalIssues { get; set; }
        public int BooksOnHand { get; set; }
        public DateTime? FirstIssue { get; set; }
        public DateTime? LastIssue { get; set; }
    }

    public class BookPopularityViewModel
    {
        public int BookId { get; set; }
        public string BookTitle { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public int? PublicationYear { get; set; }
        public string Department { get; set; } = string.Empty;
        public int IssueCount { get; set; }
        public int UniqueReaders { get; set; }
    }

    public class MonthlyStatisticsViewModel
{
        public string Month { get; set; } = string.Empty;
        public int TotalIssues { get; set; }
        public int UniqueReaders { get; set; }
        public int UniqueBooks { get; set; }
        public double AverageLoanPeriod { get; set; }
    }
}