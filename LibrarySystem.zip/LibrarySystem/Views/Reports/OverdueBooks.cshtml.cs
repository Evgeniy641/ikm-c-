using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LibrarySystem.Views.Reports
{
    public class OverdueBooksModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
